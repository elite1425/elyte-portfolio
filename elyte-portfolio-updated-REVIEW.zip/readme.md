# ELYTE – Personal Portfolio

Static site (HTML + CSS + vanilla JS). No build step, no dependencies, no backend.

## Folder structure
```
elyte-portfolio/
├── index.html          # all content + SEO / Open Graph tags
├── css/styles.css      # design tokens (colours) at the top in :root
├── js/main.js          # nav, scroll effects, year, Canvas globe
├── assets/
│   ├── favicon.svg     # ELYTE "E" mark
│   └── og-image.png    # 1200x630 social share image
└── README.md
```

## 1. Preview locally
Pick one:
- **Double-click `index.html`** – works in any browser.
- **Python:** `cd elyte-portfolio && python3 -m http.server 8080` → open http://localhost:8080
  (works in Termux too: `pkg install python`).
- **VS Code:** install "Live Server" → right-click `index.html` → Open with Live Server.

## 2. Deploy free (choose one)
**Netlify (fastest, no account tools needed)**
1. Go to app.netlify.com/drop and drag the `elyte-portfolio` folder in.
2. You get a live `*.netlify.app` URL. Rename it in Site settings → Change site name.

**Cloudflare Pages**
1. Pages → Create project → Direct Upload → upload the folder.

**GitHub Pages**
1. Create a repo, upload all files (keep `index.html` at the repo root).
2. Settings → Pages → Source: "Deploy from a branch" → `main` / root → Save.
3. Site appears at `https://<username>.github.io/<repo>/`.

## 3. Connect a custom domain later
1. Buy a domain (Namecheap, Cloudflare, Porkbun, etc.).
2. In your host (Netlify / Cloudflare Pages / GitHub Pages) → Domains → Add custom domain.
3. At your domain registrar's DNS settings, add the records the host shows you
   (usually a `CNAME` for `www` and an `A`/`ALIAS` record for the root domain).
4. Wait for DNS (minutes to a few hours). HTTPS is issued automatically.
5. **Then update `index.html`:** change both `og:image` and `twitter:image` to the full URL,
   e.g. `https://your-domain.com/assets/og-image.png`. Social platforms need an absolute URL
   to show the preview image. Optionally add
   `<link rel="canonical" href="https://your-domain.com/">` in `<head>`.

## 4. Update content
| What | Where |
|---|---|
| Email / X / Telegram links | `index.html` → search `id="contact"`; also the JSON-LD block in `<head>` |
| Hero, About, Focus Areas text | `index.html` (plain text inside each section) |
| Experience / education | `index.html` → `id="experience"` |
| Colours | `css/styles.css` → `:root` variables |
| Globe speed / size | `js/main.js` → `rot += dt * 0.00011` (speed), `R = size * 0.34` (size) |
| Footer year | Automatic |

### Publishing a finished project
Each Proof of Work card sits in `index.html` under `id="proof"`. When a project is real:
1. Change the badge: `<span class="badge badge-planned">Planned Project</span>`
   → `badge badge-progress` + text `In Development`, or text `Completed` once finished.
2. Replace the description with the real scope and findings (only facts you can show).
3. Replace `<span class="link-pending">Report: coming soon</span>` with:
   `<a class="card-link" href="YOUR-REPORT-URL" target="_blank" rel="noopener noreferrer">View report →</a>`
   (a public Notion page, Google Doc/Sheet, PDF in `assets/`, or GitHub link).

## 5. Quality check (already run on this build)
- Layouts at 1440px, 820px and 390px: no horizontal scroll.
- Mobile menu opens/closes with button, link tap and Escape key.
- All anchor links resolve; email, X and Telegram links are correct.
- Keyboard: skip link, visible focus rings, logical tab order.
- Reduced-motion: globe is drawn still, no scroll animations.
- Without JavaScript: content and nav stay visible; a static globe image replaces the animation.
- No console errors.
- Re-check after deploying: open the live URL on your phone, tap every button,
  and test the share preview in the X Card Validator / Telegram.
